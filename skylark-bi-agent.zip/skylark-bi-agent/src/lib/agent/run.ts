/**
 * The agent loop.
 *
 * A plain Anthropic tool-use loop over the MCP tool set, streamed as events so
 * the UI can show reasoning, tool calls and their results as they happen
 * rather than after a long silence. Tool execution goes through `callTool`,
 * the same entry point the hosted MCP endpoint uses — so what the web agent
 * can do and what an external MCP client can do never drift apart.
 */

import Anthropic from '@anthropic-ai/sdk';
import { TOOLS, callTool } from '../mcp/tools.ts';
import { systemPrompt } from './system-prompt.ts';
import { getDataSource } from '../monday/source.ts';

export type ChatMessage = { role: 'user' | 'assistant'; content: string };

export type AgentEvent =
  | { type: 'status'; message: string }
  | { type: 'text'; delta: string }
  | { type: 'tool_start'; id: string; name: string; input: unknown }
  | { type: 'tool_end'; id: string; name: string; ok: boolean; result: unknown; ms: number }
  | { type: 'done'; usage: { inputTokens: number; outputTokens: number }; turns: number }
  | { type: 'error'; message: string; recoverable: boolean };

const MAX_TURNS = 10;

/** Trimmed so a long conversation cannot silently blow the context window. */
function toApiMessages(history: ChatMessage[]): Anthropic.MessageParam[] {
  return history.slice(-20).map((m) => ({ role: m.role, content: m.content }));
}

/**
 * Tool results can be large — a 100-row query is tens of kilobytes. Truncating
 * keeps a long conversation affordable, and the tools are designed so the
 * important parts (totals, coverage, caveats) come first in the JSON.
 */
function serializeResult(result: unknown, limit = 24_000): string {
  const json = JSON.stringify(result, null, 1);
  if (json.length <= limit) return json;
  return json.slice(0, limit) + `\n… truncated (${json.length} chars). Narrow the query or request fewer fields.`;
}

export async function* runAgent(
  messages: ChatMessage[],
  opts: { apiKey: string; model?: string; signal?: AbortSignal } ,
): AsyncGenerator<AgentEvent> {
  const client = new Anthropic({ apiKey: opts.apiKey });
  const model = opts.model ?? 'claude-sonnet-4-5';

  let source: 'live' | 'mock' = 'live';
  try {
    source = getDataSource().kind;
  } catch {
    // Configuration problem surfaces on the first tool call with a better message.
  }

  const system = systemPrompt({ source });
  const tools: Anthropic.Tool[] = TOOLS.map((t) => ({
    name: t.name,
    description: t.description,
    input_schema: t.inputSchema as Anthropic.Tool.InputSchema,
  }));

  const convo: Anthropic.MessageParam[] = toApiMessages(messages);
  let inputTokens = 0;
  let outputTokens = 0;

  for (let turn = 1; turn <= MAX_TURNS; turn++) {
    if (opts.signal?.aborted) return;

    let assistantBlocks: Anthropic.ContentBlock[] = [];
    let stopReason: string | null = null;

    try {
      const stream = client.messages.stream(
        { model, max_tokens: 4096, system, tools, messages: convo },
        { signal: opts.signal },
      );

      stream.on('text', () => { /* deltas are consumed below */ });

      for await (const event of stream) {
        if (event.type === 'content_block_delta' && event.delta.type === 'text_delta') {
          yield { type: 'text', delta: event.delta.text };
        }
        if (event.type === 'content_block_start' && event.content_block.type === 'tool_use') {
          yield { type: 'status', message: `Querying ${event.content_block.name.replace(/_/g, ' ')}…` };
        }
      }

      const final = await stream.finalMessage();
      assistantBlocks = final.content;
      stopReason = final.stop_reason;
      inputTokens += final.usage.input_tokens;
      outputTokens += final.usage.output_tokens;
    } catch (err) {
      if (opts.signal?.aborted) return;
      yield { type: 'error', ...describeLlmError(err) };
      return;
    }

    convo.push({ role: 'assistant', content: assistantBlocks });

    if (stopReason !== 'tool_use') {
      yield { type: 'done', usage: { inputTokens, outputTokens }, turns: turn };
      return;
    }

    const toolUses = assistantBlocks.filter(
      (b): b is Anthropic.ToolUseBlock => b.type === 'tool_use',
    );

    const results: Anthropic.ToolResultBlockParam[] = [];
    for (const use of toolUses) {
      if (opts.signal?.aborted) return;
      yield { type: 'tool_start', id: use.id, name: use.name, input: use.input };

      const started = Date.now();
      const result = await callTool(use.name, (use.input ?? {}) as Record<string, unknown>);
      const ms = Date.now() - started;
      const isError = Boolean(result && typeof result === 'object' && (result as { error?: boolean }).error);

      yield { type: 'tool_end', id: use.id, name: use.name, ok: !isError, result, ms };

      results.push({
        type: 'tool_result',
        tool_use_id: use.id,
        content: serializeResult(result),
        is_error: isError,
      });
    }

    convo.push({ role: 'user', content: results });
  }

  yield {
    type: 'error',
    message: `Stopped after ${MAX_TURNS} rounds of tool calls without reaching an answer. The question may need to be narrower.`,
    recoverable: true,
  };
}

function describeLlmError(err: unknown): { message: string; recoverable: boolean } {
  const e = err as { status?: number; error?: { error?: { message?: string } }; message?: string };
  const detail = e?.error?.error?.message ?? e?.message ?? String(err);

  if (e?.status === 401) {
    return { message: 'The Anthropic API key was rejected. Check ANTHROPIC_API_KEY.', recoverable: false };
  }
  if (e?.status === 400 && /credit balance/i.test(detail)) {
    return {
      message: 'The Anthropic account has no credits left. Add credits at console.anthropic.com → Plans & Billing.',
      recoverable: false,
    };
  }
  if (e?.status === 429) {
    return { message: 'Rate limited by the Anthropic API. Try again in a few seconds.', recoverable: true };
  }
  if (e?.status && e.status >= 500) {
    return { message: 'The Anthropic API had a server error. Retrying usually works.', recoverable: true };
  }
  return { message: detail.slice(0, 300), recoverable: true };
}
