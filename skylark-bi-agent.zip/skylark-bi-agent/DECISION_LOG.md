# Decision Log

**Skylark Drones — monday.com Business Intelligence Agent**

---

## The problem as I read it

The brief asks for an agent that answers founder questions from monday.com. The hard part is not the querying — it is that **almost every interesting field in this data is partly missing**, and a BI agent that reports totals without denominators will confidently tell a founder the pipeline is half its real size. Most of my time went into making the agent honest rather than making it clever.

## Key assumptions

**1. "This quarter" means the Indian financial year quarter (Apr–Mar).** Skylark is an Indian company; invoice numbers in the source are stamped `SDPL/FY25-26/…`, which confirms an April year-start. Calendar quarters are still available explicitly (`CQ3_2025`). Every resolved period reports which convention it used, and the agent states the actual months in its answer so the reader can catch a wrong assumption immediately.

**2. Ambiguous `DD/MM/YYYY` dates are day-first.** Every unambiguous row in the source (day > 12) is day-first without exception. Month-first parsing would silently mis-date about a third of the calendar.

**3. `Tender` and `DSP` are not industry sectors.** They sit in the deals board's `Sector/service` column but describe routes to market. This matters more than it sounds: **`Tender` alone accounts for ₹53.2 Cr of the ₹68.8 Cr open pipeline** — leave it in a sector ranking and it drowns every real sector. The normalizer tags each value's *kind*, the agent excludes non-sectors from sector analysis, and says that it did.

**4. Deal values are masked but internally consistent.** Ratios, rankings and comparisons are meaningful; absolute rupee figures are not the company's real numbers. The agent says this once per conversation rather than on every line.

**5. Probability weights of High 0.75 / Medium 0.45 / Low 0.20 are mine, not Skylark's.** No weighting model was supplied. The agent labels the weighted figure as a working convention wherever it quotes one.

**6. GST is exactly 18% throughout** — verified across all 169 rows where both figures exist. This lets missing incl/excl values be derived rather than dropped.

## Trade-offs

**Analytical MCP tools, not a GraphQL passthrough.** The tools are `aggregate`, `cross_board_summary`, `data_quality_report` — not `run_query`. Founder questions almost never map to "fetch rows"; they map to "aggregate this metric over that slice and tell me what's missing". Pushing that into the tool layer means the model never does arithmetic in its head, which is where BI agents start inventing numbers. **Cost:** a question outside the tools' shape needs a new tool rather than an ad-hoc query.

**Whole-board fetch with a 60-second cache, filtered in process.** monday's server-side filtering cannot express cross-board joins, coverage-aware aggregation, or derived fields like "open past its expected close date". The boards are 344 and 176 rows. One fetch per cache window is far cheaper than a new API call for every filter the agent explores mid-conversation. **Cost:** this does not scale to 100k-row boards — at that size the aggregation would have to move server-side, or into a warehouse.

**Charts are rendered from tool results, never from model output.** If the model emitted chart data, a hallucinated number could be drawn as a confident bar. Deriving the figure from the same JSON the tool returned means the picture and the prose cannot disagree. **Cost:** less flexible charting.

**Two transports over one tool definition.** The same handlers serve the hosted MCP endpoint (`/api/mcp`) and the in-process agent, so what an external MCP client can do and what the web UI can do never drift apart. The stateless JSON-RPC endpoint is hand-written against the wire format because the SDK's Node transport wants `req`/`res` objects that Next's Web `Request` does not provide.

**Next.js on Vercel, one deployable.** UI, agent and MCP server ship together — one URL, no local setup, which the brief requires. **Cost:** the 60-second serverless limit bounds a very long agent run.

**A mock data source, used only in tests.** `DATA_SOURCE=mock` replays the workbooks through the identical interface so the query engine can be tested without an account. The generated fixture is gitignored, the hosted demo runs `live`, and nothing above that seam can tell the difference — which is what makes the 35 unit tests worth anything.

## What the data actually contained

Worth recording, because several of these are invisible until you look:

- **Two repeated header rows buried inside the deals data** (rows 50 and 179) — each with a plausible deal name in the first cell, so a naive header check misses them. Detected by matching *other* cells against their own column headers.
- **Four columns are completely empty**: Expected Billing Month, Actual Collection Month, Collection Status, Collection Date. The last one means true AR ageing cannot be computed at all — only balances. The agent says so rather than approximating.
- **Client codes cannot be joined across boards** — `COMPANY089` vs `WOCOMPANY_002` are different masking schemes. Owner code and deal name are the only real join keys.
- **Two competing billing columns that disagree**, one containing the typo `BIlled`. Reconciled using billed value as the tie-breaker, since money is 100% populated and the status columns are hand-maintained.
- **Six work orders billed above their order value**, and **49 past their end date but not marked complete**. Surfaced as anomalies, not silently clamped.
- **`NONE` is a real answer**, not a blank — it means "no Skylark platform attached" on 127 of 176 rows. My first blank-value list swallowed it and made platform-attach rate read 21% instead of 93%. Caught by cross-checking against the profiling numbers; there is now a regression test.
- **The boards end around April 2026.** Against today's date, "this quarter" legitimately matches nothing. Answering "₹0" would read as a business collapse rather than a gap in the records, so the tools return the actual populated date range whenever a period filter matches nothing, and the agent is required to check `data_time_range` before any time-bounded question.

## How I interpreted "the agent should help prepare data for leadership updates"

I read this as: **a founder should be able to ask once a week and get something they could paste into a board email** — not a dashboard, and not a data dump.

So `leadership_brief` assembles the standing numbers in a single call — pipeline and weighted pipeline, funnel shape, win rate, sector mix, order book, execution status, billing and collections, top receivables — with the **data-quality caveats included as a first-class section**, because anything going to a board needs its own footnotes. Using one tool rather than a dozen `aggregate` calls also means the definitions are identical every week, so week-on-week comparisons are real rather than an artefact of the agent phrasing the query differently.

The agent is instructed to return a *written brief* — what moved, what is at risk, what needs a decision — rather than every number it could measure.

## What I would do differently with more time

- **Snapshot the boards on a schedule.** Nothing here is time-series: I can say the pipeline is ₹68.8 Cr but not that it grew. Weekly snapshots would turn every metric into a trend, which is most of what a founder actually wants.
- **Push aggregation server-side** behind the same tool interface, so the design survives boards 100× larger.
- **Write back to monday.com.** The agent finds 49 overdue work orders and 6 over-billings but cannot flag them on the board. The brief specifies read-only, so this stayed out.
- **Reconcile the two boards properly.** With only masked names to join on, "which pipeline deals became work orders" is currently approximate. A shared key would make conversion rate and cycle time answerable.
- **Evaluate the agent, not just the engine.** The 35 tests cover normalization and aggregation. The agent's *judgement* — does it pick the right tool, does it caveat when it should — is checked by hand via `npm run smoke`. A graded question set with expected tool sequences would catch prompt regressions properly.
- **Let a founder correct the data from the conversation.** The agent knows exactly which 2 open deals have no value. Asking "want me to flag these?" would close the loop between finding bad data and fixing it.
